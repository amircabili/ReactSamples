import React from "react";
import { IndexLink, Link } from "react-router";
 
   
export default class Nav extends React.Component {
  constructor() {
    super()
    this.state = {
      collapsed: true,
    };
  }

  toggleCollapse() {
    const collapsed = !this.state.collapsed;
    this.setState({collapsed});
  }
  

  navigate(){
    
  }

  render() {

    const navStyles = {
      transition: "height 3.5s ease"
   };

    
  const { location } = this.props;
  const { collapsed } = this.state;

  const featuredClass = location.pathname === "/" ? "active" : "";
  const archivesClass = location.pathname.match(/^\/archives/) ? "active" : "";
  const settingsClass = location.pathname.match(/^\/settings/) ? "active" : "";
  const todosClass = location.pathname.match(/^\/todos/) ? "active" : "";

  const navClass = collapsed ? "collapse" : "";

    const { history } = this.props;
    //console.log(history.isActive( ));


    return (
      <nav class="navbar navbar-inverse  navbar-fixed-top" role="navigation">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" onClick={this.toggleCollapse.bind(this)}>
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
          <div  id="bs-example-navbar-collapse-1" class={"navbar-collapse " + navClass} style={navStyles}>
            <ul class="nav navbar-nav">
              <li class={featuredClass}>
                <IndexLink activeClassName="active" to="/" onClick={this.toggleCollapse.bind(this)}>Featured</IndexLink>
              </li>
              <li class={archivesClass}>
                <Link activeClassName="active" to="archives" onClick={this.toggleCollapse.bind(this)}><button className="btn btn-success">Archives</button></Link>
              </li>
              <li class={settingsClass}>
                <Link activeClassName="active" to="settings" onClick={this.toggleCollapse.bind(this)}>Settings</Link>
              </li>
              <li class={todosClass}>
                <Link activeClassName="active" to="todos" onClick={this.toggleCollapse.bind(this)}>Todos</Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    );
  }
}
